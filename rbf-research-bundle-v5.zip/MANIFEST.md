# RBF Research — Handoff Bundle Manifest

**Project:** Revenue-Contingent Financing Under Volatile Sales — A Model-Based and Simulation Study Motivated by Vietnamese E-commerce Sellers

> ⚠️ **This folder's location is TEMPORARY.** It sits inside an unrelated Excel research folder only because that was the single writable location available. It is a backup, not the project's home. Final destination is the `sellerflow` repository. Nothing here depends on, reads, or relates to any Excel file.

**Created:** 2026-08-03 · **Updated:** 2026-08-04 (bundle **v5** — P7 finite-time boundary + completion-concept split) · **Spec:** `METHODOLOGY_SPEC.md` v1.0 + amendments A-1…A-6

> This folder is **self-contained and independent of any temporary environment**. Everything needed to reproduce every number in the project is here.
>
> ⚠️ All quantitative output is **simulation under modeled assumptions**. No observed seller revenue, repayment, or default outcome exists in this project.
>
> **Note on location:** this bundle lives in `rbf-research/` inside a folder containing a separate, unrelated research project. Nothing outside `rbf-research/` and `patches/` was read, modified, or depended upon.

---

## Files

### `research/` — documents

| File | Purpose |
|---|---|
| `METHODOLOGY_SPEC.md` | **The frozen specification.** Population, unit of analysis, horizon, revenue-path generation, seasonality and shocks, both fixed benchmarks, matched-comparison rules, metric formulas, seeds, sensitivity ranges, exclusion rules, interpretation limits. §16 logs all amendments. Frozen before any outcome analysis. |
| `DECISION_LOG.md` | Every decision with date, alternatives, reason, consequence. Includes the methodological correction (D-001) and all supersessions. Append-only. |
| `RESULTS_REGISTRY.md` | Every result with scenario, parameters, code, interpretation, limitation, and public-safety classification. Includes both preserved null results (R-013). |
| `CORRECTED_CLAIMS.md` | **Current claim set.** Corrected interpretation layer, pricing sensitivity, equal-effective-cost cap, convergence, recovery boundary, RBF-G decision, revenue definition, parameter classification. |
| `DERIVATIONS.md` | **Analytical backbone.** Seven propositions with proofs, holding for any revenue path independent of simulation or parameters. Includes the five-class claim taxonomy and the rejected RBF-G design. |
| `PHASE0_AUDIT.md` | Original audit: 8 integrity risks, 6 gaps, evidence appendix. |
| `BASELINE_FINDINGS.md` | `baseline_v1` results. **Partly superseded** — banner at top explains what and why. Retained for audit trail. |
| `METRIC_DEFINITIONS.md` | v0.1, **superseded** by `METHODOLOGY_SPEC.md`. Retained for audit trail. |
| `BACKLOG.md` | Prioritized execution backlog, freeze list, cut list. |

### `research/rbf_sim/` — simulation package

| File | Purpose |
|---|---|
| `generator.py` | Revenue-path generation. **Accounting identities enforced**: `gmv = orders × AOV` exact; returns and fees are deductions. Seasonality, 9 shock types incl. closure. |
| `contracts.py` | FIX-A (matched principal/total/term), FIX-B (amortizing annuity), RBF, RBF-G. Pure arithmetic, no model calls. APR solver. |
| `metrics.py` | Payment burden, high-payment-burden months, duration, total repaid, recovery at checkpoints, incomplete recovery, post-shock recovery, underreporting. |
| `engine.py` | Paired runner — one path, all contracts. Monte Carlo intervals with self-describing labels. |
| `README.md` | Package overview and terminology rules. |
| `tests/test_identities.py` | Accounting-identity tests. Regression guard for the 61%-violation defect. |
| `tests/test_contracts.py` | Contract and metric tests, all expected values hand-derived. |
| `tests/test_derivations.py` | Validates every proposition in `DERIVATIONS.md` against the engine, across adversarial paths (zeros, spikes, seasonal, trending). |

### `research/analysis/` — standalone analyses

| File | Purpose |
|---|---|
| `00_audit_evidence.py` | Reproduces the three audit findings: circular AUC, impossible population, engine self-contradiction. |
| `01_verify_spec.py` | Five checks that the frozen spec is implementable. Produced coherence constraint §3.4. |

### `research/` — run scripts

| File | Purpose |
|---|---|
| `run_baseline.py` | 10 scenarios × 4 contracts × 500 paths → `results/baseline_v2.json` |
| `run_validation.py` | Sections 1/2/4/5/6 → `results/validation_v1.json` |
| `conv_step.py` | Single-N convergence step (large N split to avoid timeouts) |

### `research/results/` — versioned outputs

| File | Purpose |
|---|---|
| `baseline_v2.json` | **Current baseline.** `net_sales` remittance basis. |
| `baseline_v1.json` | Superseded (`gmv` basis). Audit trail. |
| `validation_v1.json` | Convergence, pricing, equal-cost cap, recovery boundary, RBF-G breakpoint, revenue definition. |
| `baseline_v2_log.txt` | Full console output of the baseline run. |

### `patches/`

| File | Purpose |
|---|---|
| `README_corrections.patch` | Verified with `git apply --check` against `sellerflow` origin/HEAD. Removes stale deployment link, withdraws 0.92 AUC with the circularity arithmetic, adds research-integrity statement, removes `demo2025` default, de-hardcodes test count. |
| `README.corrected.md` | The resulting README in full, if you prefer to replace rather than patch. |

---

## Reproducing every result

```bash
cd rbf-research/research
pip install pytest numpy          # only dependencies

# 1. Test suite  (expect: 461 passed)
python3 -m pytest rbf_sim/tests/ -q

# 2. Baseline — 10 scenarios x 4 contracts x 500 paths
python3 run_baseline.py                     # -> results/baseline_v2.json

# 3. Validation battery
python3 run_validation.py 2                 # pricing + equal-effective-cost cap
python3 run_validation.py 4                 # incomplete-recovery boundary
python3 run_validation.py 5                 # RBF-G breakpoint
python3 run_validation.py 6                 # revenue-definition sensitivity

# 4. Monte Carlo convergence (run separately; 10k paths takes ~45s)
python3 conv_step.py 500
python3 conv_step.py 2000
python3 conv_step.py 5000
python3 conv_step.py 10000

# 5. Audit evidence — requires the sellerflow repo's backend/ on the path
cd /path/to/sellerflow/backend
python3 /path/to/rbf-research/research/analysis/00_audit_evidence.py

# 6. Spec verification (standalone, no dependencies)
python3 rbf-research/research/analysis/01_verify_spec.py
```

**Determinism.** Base seed `20260803`, bootstrap seed `90210`. Identical seeds reproduce bit-for-bit. Any run that does not reproduce is a bug, not variance.

### Applying the README patch

```bash
cd /path/to/sellerflow
git apply /path/to/rbf-research/patches/README_corrections.patch
# verified to apply cleanly against origin/HEAD as of 2026-08-03
```

---

## Expected key numbers

Spot-check any reproduction against these:

| Quantity | Value | Source |
|---|---|---|
| Simulation tests passing | 461 | `pytest rbf_sim/tests/ -q` |
| Backend tests passing (unmodified repo) | 47 | `pytest backend/tests/ -q` |
| Matched benchmark term / payment | 13 months / 17,076,923 VND | `baseline_v2` |
| Benchmark A implied APR | 37.87% | `baseline_v2` |
| Benchmark B effective APR | 19.5618% | `validation_v1` |
| **Equal-effective-cost cap `f*`** | **1.0945** (19.5377% APR) | `validation_v1` |
| Convergence Δ 5,000→10,000 | 0.0027 months, 0.042pp | `validation_v1` |
| Accounting-identity violations | 0 of ~2,400 rows | `test_cohort_wide_identity_holds_for_every_row` |
| Circular-AUC evidence | 0.9098 generating fn vs 0.9182 model | `00_audit_evidence.py` |
| Geometric completion threshold `ρ*` | 11/12 ≈ 0.9167 | `test_P7_geometric_threshold_rho_star_is_one_minus_r_B0_over_FA` |
| P7 completion inequality | **strict** — `ρ > ρ*`; `ρ = ρ*` never completes in finite time | `test_P7_at_rho_star_every_finite_partial_sum_is_strictly_below_the_cap` |
| Operational completion at `ρ*`, `ε`=1.0 / 0.5 / 0.01 | T = 213 / **221** / 266 (engine default ε = 0.5) | `test_P7_operational_completion_flip_point_by_epsilon` |
| Mathematical completion at `ρ*` | never, for any finite T | `test_P7_mathematical_completion_never_occurs_at_rho_star_for_any_epsilon` |
| Tolerance impact on registered results | zero — 0 of 10 scenarios change | `test_P7_engine_tolerance_is_not_a_binding_settlement_policy` |

---

## Status

**Complete:** Phase 0 audit · frozen methodology · corrected generator · simulation package · baseline · validation battery · corrected claims · README patch · **analytical backbone (7 propositions, test-validated)**.

**Not started:** product integration · paper · poster · deck · deployment.

**Not in this project:** Excel. Removed entirely per instruction 2026-08-03 — no dependency, assumption, deliverable, blocker, or reconciliation task remains.
